window.addEventListener('load', function () {
    $(".contest-entry-join__details").css('display','block');
});